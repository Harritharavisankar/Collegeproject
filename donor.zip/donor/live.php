<?php
ignore_user_abort(true);  // Continue even if the user closes the browser
set_time_limit(0);  // Prevent timeout

include("db.php");

$check_interval = 60; // Time in seconds between each check

while (true) {
    // Fetch all donor users
    $sql = "SELECT * FROM donor_user";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $email = $row["email"];
            $dob = $row["dob"];
            $uid = $row["uid"];
            
            $spl = date("m-d", strtotime($dob));
            $current = date("m-d");
            $today = date("Y-m-d");  // Get current date in Y-m-d format

            // Check if it's the user's birthday
            if ($spl == $current) {
                // Check if birthday email was already sent today
                $checkEmailLog = "SELECT * FROM email_log WHERE uid = $uid AND email_sent_date = '$today' AND email_type = 'birthday'";
                $emailLogResult = mysqli_query($conn, $checkEmailLog);

                if (mysqli_num_rows($emailLogResult) == 0) {
                    // Send the birthday email
                    include("mail1.php");

                    // Log the email sent in the email_log table
                    $logEmail = "INSERT INTO email_log (uid, email_sent_date, email_type) VALUES ($uid, '$today', 'birthday')";
                    mysqli_query($conn, $logEmail);
                }
            }

            // Check special dates
            $sql12 = "SELECT * FROM special_date WHERE uid = $uid";
            $result12 = mysqli_query($conn, $sql12);

            if (mysqli_num_rows($result12) > 0) {
                while ($row12 = mysqli_fetch_assoc($result12)) {
                    $reason = $row12["reason"];
                    $spldate = $row12["spl_date"];

                    // Extract month and day from the special date
                    $splMonthDay = date("m-d", strtotime($spldate));

                    if ($splMonthDay == $current) {
                        // Check if special date email was already sent today
                        $checkSpecialDateLog = "SELECT * FROM email_log WHERE uid = $uid AND email_sent_date = '$today' AND email_type = 'special'";
                        $specialLogResult = mysqli_query($conn, $checkSpecialDateLog);

                        if (mysqli_num_rows($specialLogResult) == 0) {
                            // Send the special date email
                            include("mail.php");

                            // Log the email sent in the email_log table
                            $logSpecialEmail = "INSERT INTO email_log (uid, email_sent_date, email_type) VALUES ($uid, '$today', 'special')";
                            mysqli_query($conn, $logSpecialEmail);
                        }
                    }
                }
            }
        }
    }

    // Sleep for the specified interval before checking again
    sleep($check_interval);
}
