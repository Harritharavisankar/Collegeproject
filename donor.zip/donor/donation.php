<?php
session_start();
include("db.php");

if (!isset($_SESSION['uid'])) {
    header("Location: index.php");
    exit();
}
$uid = $_SESSION["uid"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        /* Global Styles */
        body {
            background: linear-gradient(135deg, #f0f4f8, #d9e6f2);
            font-family: 'Poppins', sans-serif;
            color: #333;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Navbar Styles */
        .navbar {
            background-color: #343a40; /* Dark background */
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s;
        }

        .navbar-brand {
            font-weight: 700;
            color: #ffc107; /* Amber color */
            transition: color 0.3s;
        }

        .navbar-brand:hover {
            color: #fff;
        }

        .navbar-nav .nav-link {
            color: #f8f9fa; /* Light text */
            margin-left: 15px;
            transition: color 0.3s, border-bottom 0.3s;
        }

        .navbar-nav .nav-link:hover {
            color: #ffc107; /* Highlight on hover */
            border-bottom: 2px solid #ffc107;
        }

        .navbar-nav .nav-link.active {
            color: #ffc107;
            border-bottom: 2px solid #ffc107;
        }

        .btn-danger {
            margin-left: 15px;
            padding: 8px 16px;
            transition: background-color 0.3s;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        /* Form Container */
        .form-container {
            background-color: #ffffff;
            border-radius: 20px;
            padding: 50px 40px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            max-width: 700px;
            width: 100%;
            margin: 40px auto;
            position: relative;
            overflow: hidden;
            animation: fadeIn 1s ease-in-out;
        }

        /* Header */
        .form-container h2 {
            text-align: center;
            font-weight: 700;
            color: #007bff;
            margin-bottom: 30px;
            position: relative;
        }

        .form-container h2::after {
            content: '';
            width: 60px;
            height: 4px;
            background: #ffc107;
            position: absolute;
            left: 50%;
            bottom: -10px;
            transform: translateX(-50%);
            border-radius: 2px;
        }

        /* Form Groups */
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            font-weight: 600;
            color: #555;
            display: block;
            margin-bottom: 8px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #d1d3e2;
            border-radius: 10px;
            font-size: 16px;
            background-color: #f9f9fc;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            background-color: #fff;
            box-shadow: 0 4px 10px rgba(0, 123, 255, 0.2);
        }

        /* Submit Button */
        .form-container button {
            background: linear-gradient(45deg, #007bff, #3f51b5);
            color: white;
            border: none;
            border-radius: 30px;
            padding: 15px;
            font-size: 18px;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s ease, transform 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 123, 255, 0.2);
        }

        .form-container button:hover {
            background: linear-gradient(45deg, #3f51b5, #007bff);
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 123, 255, 0.3);
        }

        /* Animated Elements */
        #donation-date, #card-details {
            display: none;
            animation: slideIn 0.5s forwards;
        }

        /* Keyframes */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { opacity: 0; height: 0; }
            to { opacity: 1; height: auto; }
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .form-container {
                padding: 30px 20px;
            }

            .navbar-nav .nav-link {
                margin-left: 10px;
                font-size: 14px;
            }
        }

        /* Alert Animations */
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            display: none;
            animation: slideInRight 0.5s forwards, fadeOut 3s 2.5s forwards;
        }

        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(100%); }
            to { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">My Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="dashboard.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php">Donations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="history.php">History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Donation Form -->
<div class="form-container">
    <h2>Make a Donation</h2>
    <form action="" method="post" id="donationForm">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" required>
            <input type="hidden" name="uid" value="<?=$uid?>">
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="org">Select Organization</label>
            <select name="org" id="org" required>
                <option value="" disabled selected>Select Organization</option>
                <?php
                    $sql1 = "SELECT * FROM recipient";
                    $result1 = mysqli_query($conn, $sql1);
                    if(mysqli_num_rows($result1) > 0) {
                        while($row1 = mysqli_fetch_assoc($result1)) {
                            echo "<option value='".$row1["rid"]."'>".$row1["org_name"]."</option>";
                        }
                    }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="donationType">Type of Donation</label>
            <select id="donationType" name="donation_type" required>
                <option value="" disabled selected>Select Donation Type</option>
                <option value="money">Money</option>
                <option value="food">Food</option>
                <option value="cloth">Cloth</option>
                <option value="book">Book</option>
            </select>
        </div>

        <div class="form-group" id="donation-date">
            <label for="donationDate">Date of Donation</label>
            <input type="date" id="donationDate" name="donation_date">
        </div>

        <!-- Card Details for money donations -->
        <div id="card-details">
            <div class="form-group">
                <label for="card_number">Card Number</label>
                <input type="text" name="card_number" id="card_number" placeholder="Card Number" pattern="\d{16}" title="Enter a 16-digit card number">
            </div>
            <div class="form-group">
                <label for="card_name">Name on Card</label>
                <input type="text" name="card_name" id="card_name" placeholder="Name on Card">
            </div>
            <div class="form-group">
                <label for="expiry_date">Expiry Date</label>
                <input type="text" name="expiry_date" id="expiry_date" placeholder="Expiry Date (MM/YY)" pattern="^(0[1-9]|1[0-2])\/\d{2}$" title="Enter in MM/YY format">
            </div>
            <div class="form-group">
                <label for="cvv">CVV</label>
                <input type="text" name="cvv" id="cvv" placeholder="CVV" pattern="\d{3}" title="Enter a 3-digit CVV">
            </div>
            <div class="form-group">
                <label for="amount">Amount ($)</label>
                <input type="number" name="amount" id="amount" placeholder="Amount" min="1">
            </div>
        </div>

        <button type="submit" name="submit" class="mt-4">Submit Donation</button>
    </form>
</div>

<!-- Alert Container -->
<div id="alert-container">
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $uid = mysqli_real_escape_string($conn, $_POST['uid']);
        $org = mysqli_real_escape_string($conn, $_POST['org']);
        $donation_type = mysqli_real_escape_string($conn, $_POST['donation_type']);

        if ($donation_type == 'money') {
            $card_name = mysqli_real_escape_string($conn, $_POST['card_name']);
            $card_number = mysqli_real_escape_string($conn, $_POST['card_number']);
            $expiry_date = mysqli_real_escape_string($conn, $_POST['expiry_date']);
            $cvv = mysqli_real_escape_string($conn, $_POST['cvv']);
            $amount = mysqli_real_escape_string($conn, $_POST['amount']);

            // Basic validation
            if (!preg_match('/^\d{16}$/', $card_number) || !preg_match('/^\d{3}$/', $cvv) || !preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry_date) || $amount < 1) {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        Invalid payment details. Please check your input.
                      </div>';
            } else {
                // Dummy payment processing
                $payment_success = true; // In real scenario, integrate payment gateway

                if ($payment_success) {
                    $donation_date = date("Y-m-d");
                    $query = "INSERT INTO donations (uid, name, email, org, donation_type, card_holder, card_number, expiry_date, cvv, donation_date, donation_amount) 
                              VALUES ('$uid', '$name', '$email', '$org', '$donation_type', '$card_name', '$card_number', '$expiry_date', '$cvv', '$donation_date', '$amount')";

                    if (mysqli_query($conn, $query)) {
                    echo '<script>alert("Donation successfully recorded.");window.location.replace("donation.php");</script>';
                    // echo 'Donation successfully recorded.';
                    } else {
                        echo '<script>alert("Error: Could not process donation. Please try again.");</script>'.mysqli_error($conn);
                    }
                } else {
                    echo '<script>alert("Payment failed. Please try again.");window.location.replace("donation.php");</script>';
                }
            }
        } else {
            $donation_date = mysqli_real_escape_string($conn, $_POST['donation_date']);

            if (empty($donation_date)) {
                echo '<script>alert("Please select a donation date.")</script>';
            } else {
                $query = "INSERT INTO donations (uid, name, email, org, donation_type, donation_date) 
                          VALUES ('$uid', '$name', '$email', '$org', '$donation_type', '$donation_date')";

                if (mysqli_query($conn, $query)) {
                    echo '<script>alert("Donation successfully scheduled.");window.location.replace("donation.php");</script>';
                } else {
                    echo '<script>alert("Failed to schedule the donation. Please try again.");window.location.replace("donation.php")</script>';
                }
            }
        }
    }
    ?>
</div>

<!-- jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom JS for Animations -->
<script>
    $(document).ready(function() {
        // Toggle between money and other donation types
        $('#donationType').on('change', function() {
            if ($(this).val() === 'money') {
                $('#donation-date').slideUp();
                $('#card-details').slideDown();
            } else {
                $('#card-details').slideUp();
                $('#donation-date').slideDown();
            }
        });

        // Automatically hide alerts after 3 seconds
        setTimeout(function() {
            $('.alert').alert('close');
        }, 5000);
    });
</script>
</body>
</html>
