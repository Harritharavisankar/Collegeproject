<?php 
session_start();
include("db.php");

if (!isset($_SESSION['rid'])) {
    header("Location: index.php");
    exit();
}

$rid = $_SESSION['rid'];
$sql = "SELECT * FROM recipient WHERE rid = '$rid'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();
$userName = $user['org_name']; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #e9ecef;
            font-family: 'Poppins', sans-serif;
        }

        .navbar {
            background-color: #007bff;
        }

        .navbar-brand {
            font-weight: bold;
            color: #fff;
        }

        .navbar-nav .nav-link {
            color: #fff;
            transition: color 0.3s;
        }

        .navbar-nav .nav-link:hover {
            color: #ffc107;
        }

        .container {
            margin-top: 30px;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            font-weight: 700;
            color: #343a40;
            margin-bottom: 10px;
        }

        .header p {
            font-size: 18px;
            color: #6c757d;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            background-color: #fff;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .card-icon {
            font-size: 50px;
            color: #007bff;
        }

        .card-title {
            font-size: 22px;
            font-weight: 600;
            margin-top: 10px;
        }

        .card-text {
            font-size: 16px;
            color: #6c757d;
        }

        .logout-btn {
            margin-top: 40px;
            text-align: center;
        }

        .logout-btn a {
            background-color: #dc3545;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        .logout-btn a:hover {
            background-color: #c82333;
        }

        @media (max-width: 768px) {
            .card {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

    <?php include("navbar.php"); ?>

    <div class="container">
        <div class="header">
            <h1 class="text-capitalize">Welcome, <?php echo htmlspecialchars($userName); ?>!</h1>
            <p>Track your history seamlessly.</p>
        </div>

        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fa-regular fa-circle-user card-icon"></i>
                        <h5 class="card-title">Profile</h5>
                        <p class="card-text">Manage your profile.</p>
                        <a href="profile.php" class="btn btn-primary">View Profile</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-history card-icon"></i>
                        <h5 class="card-title">History</h5>
                        <p class="card-text">View your transaction history.</p>
                        <a href="history.php" class="btn btn-primary">View History</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
