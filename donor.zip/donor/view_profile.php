<?php 
session_start();
include("db.php");

if (!isset($_SESSION['uid'])) {
    header("Location: index.php");
    exit();
}

$uid = $_SESSION['uid'];
$sql = "SELECT * FROM donor_user WHERE uid = '$uid'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $userName = $user['name'];
    $userEmail = $user['email']; 
    $userDob = $user['dob']; 
    $userMobile = $user['mobile'];
} else {
    echo "Error fetching user details";
    exit();
}

$specialDatesSql = "SELECT * FROM special_date WHERE uid = {$user['uid']}";
$specialDatesResult = $conn->query($specialDatesSql);
$specialDates = [];

if ($specialDatesResult && $specialDatesResult->num_rows > 0) {
    while ($row = $specialDatesResult->fetch_assoc()) {
        $specialDates[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        
        body {
            background-color: #f5f7fa;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .form-container {
            margin: 20px 0px;
            background-color: #ffffff;
            border-radius: 20px;
            padding: 30px 50px;
            max-width: 700px;
            width: 100%;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: 700;
            color: #333;
            font-size: 28px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .form-group {
            position: relative;
            margin-bottom: 30px;
        }

        .form-group label {
            font-weight: 500;
            color: #666;
            position: absolute;
            top: -10px;
            left: 20px;
            font-size: 14px;
            background: white;
            padding: 0 8px;
        }

        .form-group input,
        .form-group select {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 15px 20px;
            font-size: 16px;
            width: 100%;
            outline: none;
            background-color: #f8f9fc;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            background-color: #fff;
            box-shadow: 0px 5px 15px rgba(0, 123, 255, 0.2);
        }

        .form-container button {
            background: linear-gradient(45deg, #007bff, #3f51b5);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 12px 20px;
            font-size: 18px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            width: 100%;
        }

        .form-container button:hover {
            background: linear-gradient(45deg, #3f51b5, #007bff);
            box-shadow: 0px 5px 15px rgba(0, 123, 255, 0.4);
        }

        .add-date-btn {
            display: block;
            margin-top: 20px;
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 10px;
            font-weight: bold;
            text-align: center;
            width: 100%;
            transition: all 0.3s ease;
        }

        .add-date-btn:hover {
            background-color: #3f51b5;
            box-shadow: 0px 5px 10px rgba(63, 81, 181, 0.3);
        }

        .remove-btn {
            background-color: #ff4d4d;
            border-color: #ff4d4d;
            font-size: 14px;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            width: 100%;
            text-align: center;
        }

        .remove-btn:hover {
            color: #fff;
            background-color: #e63946;
            box-shadow: 0px 5px 10px rgba(230, 57, 70, 0.3);
        }

        .special-date-container {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }

        .col-md-4, .col-md-6 {
            flex: 1;
        }

        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

   <?php 
//    include("navbar.php");
    ?>

    <div class="form-container">
        <h2>Donor Profile Updation</h2>
        <form action="" method="post" id="registrationForm">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="<?php echo $userName; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo $userEmail; ?>" required>
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth</label>
                <input type="date" id="dob" name="dob" value="<?php echo $userDob; ?>" required>
            </div>

            <div class="form-group">
                <label for="mobile">Mobile Number</label>
                <input type="tel" id="mobile" name="mobile" value="<?php echo $userMobile; ?>" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <h5 class="text-center mt-4">Add Special Dates</h5>
            <div id="specialDateContainer">
    <?php foreach ($specialDates as $date): ?>
        <div class="form-row special-date-container">
            <div class="col-md-4">
                <input type="date" class="form-control" name="special_dates[]" value="<?php echo $date['spl_date']; ?>" required>
            </div>
            <div class="col-md-6">
                <input type="text" class="form-control" name="reasons[]" value="<?php echo $date['reason']; ?>" required>
            </div>
            <div class="col-md-2">
                <input type="hidden" name="special_date_ids[]" value="<?php echo $date['sid']; ?>"> <!-- Make sure to include the ID -->
                <button type="button" class="btn remove-btn" data-id="<?php echo $date['sid']; ?>">Remove</button>
            </div>
        </div>
    <?php endforeach; ?>
</div>


            <button type="button" class="add-date-btn" id="addSpecialDate">+ Add Special Date</button>

            <input type="hidden" name="remove_special_dates" id="remove_special_dates" value="">

            <button type="submit" class="mt-4">Update</button>
        </form>
        <footer>
            <p>© 2024 Updation Form. All rights reserved.</p>
        </footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function () {
            $('#addSpecialDate').click(function () {
    const specialDateHtml = `
        <div class="form-row special-date-container">
            <div class="col-md-4">
                <input type="date" class="form-control" name="special_dates[]" placeholder="Special Date" required>
            </div>
            <div class="col-md-6">
                <input type="text" class="form-control" name="reasons[]" placeholder="Reason for Special Date" required>
            </div>
            <div class="col-md-2">
                <!-- No hidden input for special_date_ids[] because it's a new entry -->
                <button type="button" class="btn remove-btn">Remove</button>
            </div>
        </div>`;
    $('#specialDateContainer').append(specialDateHtml);
});


            // Handle removal of special dates
            $(document).on('click', '.remove-btn', function () {
                const id = $(this).data('id');
                if (id) {
                    // Add the ID to the hidden input for removed special dates
                    const removedIds = $('#remove_special_dates').val();
                    $('#remove_special_dates').val(removedIds ? removedIds + ',' + id : id);
                }
                $(this).closest('.special-date-container').remove();
            });
        });
    </script>

</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];

    // Update the user's information
    $updateUserSql = "UPDATE donor_user SET name = '$name', email = '$email', dob = '$dob', mobile = '$mobile' WHERE uid = '$uid'";
    $conn->query($updateUserSql);

    // Handle removed special dates
    $removeSpecialDates = $_POST['remove_special_dates'];
    if (!empty($removeSpecialDates)) {
        $idsToRemove = explode(',', $removeSpecialDates);
        foreach ($idsToRemove as $id) {
            $deleteDateSql = "DELETE FROM special_date WHERE sid = '$id' AND uid = '$uid'";
            $conn->query($deleteDateSql);
        }
    }

    // Handle updating or inserting special dates
    $specialDates = $_POST['special_dates'];
    $reasons = $_POST['reasons'];
    $specialDateIds = $_POST['special_date_ids'] ?? [];

    $specialDates = $_POST['special_dates'];
$reasons = $_POST['reasons'];
$specialDateIds = $_POST['special_date_ids'] ?? []; // Check if special_date_ids[] exists

for ($i = 0; $i < count($specialDates); $i++) {
    $spl_date = $specialDates[$i];
    $reason = $reasons[$i];

    if (!empty($spl_date) && !empty($reason)) {
        if (isset($specialDateIds[$i])) { // If there's an ID, update the record
            $id = $specialDateIds[$i];
            $updateDateSql = "UPDATE special_date SET spl_date = '$spl_date', reason = '$reason' WHERE sid = '$id' AND uid = '$uid'";
            $conn->query($updateDateSql);
        } else {
            // If no ID is found, insert a new record
            $insertDateSql = "INSERT INTO special_date (uid, spl_date, reason) VALUES ('$uid', '$spl_date', '$reason')";
            $conn->query($insertDateSql);
        }
    }
}

    echo '<script>alert("Profile Updated Successfully");window.location.replace("dashboard.php");</script>';
}
?>
