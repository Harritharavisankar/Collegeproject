-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2024 at 06:47 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donor`
--

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `did` int(11) NOT NULL,
  `uid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `org` varchar(255) NOT NULL,
  `donation_type` enum('Money','Food','Cloth','Book') NOT NULL,
  `card_number` varchar(16) DEFAULT NULL,
  `card_holder` varchar(100) DEFAULT NULL,
  `expiry_date` varchar(5) DEFAULT NULL,
  `cvv` varchar(4) DEFAULT NULL,
  `donation_date` varchar(100) DEFAULT NULL,
  `donation_amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`did`, `uid`, `name`, `email`, `org`, `donation_type`, `card_number`, `card_holder`, `expiry_date`, `cvv`, `donation_date`, `donation_amount`, `created_at`) VALUES
(1, '1', 'Regubalan', 'phpprojects2024@gmail.com', '1', 'Money', '0987765412345678', 'Regubalan', '09/29', '159', '2024-10-14', 1000.00, '2024-10-14 06:00:57');

-- --------------------------------------------------------

--
-- Table structure for table `recipient`
--

CREATE TABLE `recipient` (
  `rid` int(11) NOT NULL,
  `org_name` varchar(100) NOT NULL,
  `org_email` varchar(100) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `doe` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `objective` text NOT NULL,
  `org_type` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recipient`
--

INSERT INTO `recipient` (`rid`, `org_name`, `org_email`, `owner_name`, `doe`, `address`, `objective`, `org_type`, `password`) VALUES
(1, 'Old Age Homes', 'oldagehome@gmail.com', 'Naveen', '2020-03-06', 'Near Saidapet Railway Station, Saidapet,Chennai.', '12', 'Old Age Home', '$2y$10$IsbpEsl5wt5UiiVqdnUCl.ZWm4fEVL.d2Z0i6Zg.wEiPcqmXXyeVq');

-- --------------------------------------------------------

--
-- Table structure for table `special_date`
--

CREATE TABLE `special_date` (
  `sid` int(11) NOT NULL,
  `uid` varchar(100) NOT NULL,
  `spl_date` varchar(100) NOT NULL,
  `reason` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `special_date`
--

INSERT INTO `special_date` (`sid`, `uid`, `spl_date`, `reason`) VALUES
(1, '2', '2024-10-31', 'lover birthday'),
(2, '1', '2004-06-14', 'Lover Birthday');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `name`, `email`, `dob`, `mobile`, `password`) VALUES
(1, 'Regu', 'phpprojects2024@gmail.com', '2002-03-12', '9876543210', '$2y$10$JqWBAVm.dWZ21zz/9vV0QOkOgqq7XqBg2cEd17Iu5Q3NTtIww2DpC'),
(2, 'samantha', 'ganesh@gmail.com', '2024-10-14', '6453451234', '$2y$10$al.J3GBNhpjvdPBfNORKUOG9Vq2YeRoKJPO9L6rUrTggO.XO9tFp2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`did`);

--
-- Indexes for table `recipient`
--
ALTER TABLE `recipient`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `special_date`
--
ALTER TABLE `special_date`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `recipient`
--
ALTER TABLE `recipient`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `special_date`
--
ALTER TABLE `special_date`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
