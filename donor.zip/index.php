<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor and Recipient Navigation</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #4e54c8, #8f94fb);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }

        .container {
            text-align: center;
            padding: 20px;
            width: 100%;
        }

        h1 {
            margin-bottom: 40px;
            font-size: 2.5rem;
        }

        .card-container {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }

        .card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            padding: 25px;
            width: 300px;
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
            overflow: hidden;
        }

        .card-icon {
            font-size: 50px;
            margin-bottom: 15px;
            color: #4CAF50; /* Default icon color */
        }

        .donor-card {
            border-left: 5px solid #4CAF50; /* Green border */
        }

        .recipient-card {
            border-left: 5px solid #2196F3; /* Blue border */
        }

        .card h2 {
            color: #333;
            margin: 10px 0;
        }

        .card p {
            color: #777;
            margin-bottom: 20px;
        }

        .btn {
            padding: 12px 20px;
            font-size: 16px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            background-color: #2196F3; /* Blue button */
            color: white;
            font-weight: bold;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .btn:hover {
            background-color: #1976D2; /* Darker blue on hover */
            transform: translateY(-3px);
        }

        .card:hover {
            transform: translateY(-10px); /* Raise card on hover */
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 2rem;
            }

            .card-container {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 90%;
                margin-bottom: 20px;
            }
        }

        @media (max-width: 480px) {
            h1 {
                font-size: 1.8rem;
            }

            .btn {
                padding: 10px 18px;
                font-size: 14px;
            }

            .card-icon {
                font-size: 40px;
            }
        }
    </style>

</head>
<body>
    <div class="container">
        <h1>Welcome to the Donation Portal</h1>
        <div class="card-container">
            <div class="card donor-card">
                <div class="card-icon">
                    <i class="fas fa-hand-holding-heart"></i>
                </div>
                <h2>Become a Donor</h2>
                <p>Your generosity can change lives. Join us in making a difference.</p>
                <button class="btn" onclick="navigateTo('donor')">Join as Donor</button>
            </div>
            <div class="card recipient-card">
                <div class="card-icon">
                    <i class="fas fa-user-friends"></i>
                </div>
                <h2>Get Support as a Recipient</h2>
                <p>We are here to help those in need. Find assistance today.</p>
                <button class="btn" onclick="navigateTo('recipient')">Join as Recipient</button>
            </div>
        </div>
    </div>

    <script>
        function navigateTo(type) {
            if (type === 'donor') {
                window.location.href = 'donor/index.php'; // Change to the actual donor folder path
            } else if (type === 'recipient') {
                window.location.href = 'recipient/index.php'; // Change to the actual recipient folder path
            }
        }
    </script>
</body>
</html>
