<?php 
session_start();
include("db.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .form-container {
            margin-top: 50px;
            background-color: #ffffff;
            border-radius: 20px;
            padding: 50px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: 700;
            color: #333;
            font-size: 28px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .form-group {
            margin-bottom: 30px;
        }

        .form-group label {
            font-weight: 500;
            color: #666;
            margin-bottom: 5px;
        }

        .form-group input{
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 15px 20px;
            font-size: 16px;
            width: 100%;
            outline: none;
            background-color: #f8f9fc;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            border-color: #007bff;
            background-color: #fff;
            box-shadow: 0px 5px 15px rgba(0, 123, 255, 0.2);
        }

        .form-container button {
            background: linear-gradient(45deg, #007bff, #3f51b5);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 12px 20px;
            font-size: 18px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            width: 100%;
        }

        .form-container button:hover {
            background: linear-gradient(45deg, #3f51b5, #007bff);
            box-shadow: 0px 5px 15px rgba(0, 123, 255, 0.4);
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
        }

        .register-link a {
            color: #007bff;
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

    <div class="form-container">
        <h2>Recipient Login</h2>
        <form action="" method="post" id="loginForm">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="org_email" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit">Login</button>
            <div class="register-link">
                <p>Don't have an account? <a href="register.php">Register Here</a></p>
            </div>
        </form>
        <footer>
            <p>© 2024 Login Page. All rights reserved.</p>
        </footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php 


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['org_email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM recipient WHERE org_email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Verify the password
        if (password_verify($password, $row['password'])) {
            $_SESSION["rid"] = $row["rid"];
            echo "<script>alert('Login successful!');window.location.replace('dashboard.php');</script>";
        } else {
            echo "<script>alert('Invalid password!');</script>";
        }
    } else {
        echo "<script>alert('Email not registered!');</script>";
    }

    // Close the database connection
    $conn->close();
}
?>
