<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f7fa;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }

        .form-container {
            margin: 20px 0px;
            background-color: #ffffff;
            border-radius: 20px;
            padding: 30px 50px;
            max-width: 700px;
            width: 100%;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: 700;
            color: #333;
            font-size: 28px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        .form-group {
            position: relative;
            margin-bottom: 30px;
        }

        .form-group label {
            font-weight: 500;
            color: #666;
            position: absolute;
            top: -10px;
            left: 20px;
            font-size: 14px;
            background: white;
            padding: 0 8px;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 15px 20px;
            font-size: 16px;
            width: 100%;
            outline: none;
            background-color: #f8f9fc;
            transition: all 0.3s ease;
        }

        .form-group textarea:focus,
        .form-group input:focus,
        .form-group select:focus {
            border-color: #007bff;
            background-color: #fff;
            box-shadow: 0px 5px 15px rgba(0, 123, 255, 0.2);
        }

        .form-container button,input[type=submit] {
            background: linear-gradient(45deg, #007bff, #3f51b5);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 12px 20px;
            font-size: 18px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            width: 100%;
        }

        .form-container button:hover {
            background: linear-gradient(45deg, #3f51b5, #007bff);
            box-shadow: 0px 5px 15px rgba(0, 123, 255, 0.4);
        }

        .special-date-container {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }

        .col-md-4, .col-md-6 {
            flex: 1;
        }

        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

    <div class="form-container">
        <h2>Recipient Register</h2>
        <form action="" method="post" id="registrationForm">
            <div class="form-group">
                <label for="name">Organization Name</label>
                <input type="text" id="name" name="org_name" required>
            </div>

            <div class="form-group">
                <label for="email">Organization Email</label>
                <input type="email" id="email" name="org_email" required>
            </div>

            <div class="form-group">
                <label for="owner_name">Owner Name</label>
                <input type="text" id="owner_name" name="owner_name" required>
            </div>

            <div class="form-group">
                <label for="doe">Date of Establishment</label>
                <input type="date" id="doe" name="doe" required>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <textarea name="address" id="address" required></textarea>
            </div>

            <div class="form-group">
                <label for="objective">Objectives</label>
                <textarea name="objective" id="objective" required></textarea>
            </div>

            <div class="form-group">
                <label for="org_type">Type of Organization</label>
                <select id="org_type" name="org_type" required>
                    <option value="" disabled selected>Select Organization Type</option>
                    <option value="Old Age Home">Old Age Home</option>
                    <option value="Orphanage">Orphanage</option>
                    <!-- <option value="Shelter Home">Shelter Home</option>
                    <option value="Hospital">Hospital</option>
                    <option value="School">School</option> -->
                </select>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <input type="submit" name="register" value="Register" class="mt-4">
        </form>
        <footer>
            <p>© 2024 Registration Form. All rights reserved.</p>
        </footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php 
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $org_name = $_POST['org_name'];
    $org_email = $_POST['org_email'];
    $owner_name = $_POST['owner_name'];
    $doe = $_POST['doe'];
    $address = $_POST['address'];
    $objective = $_POST['objective'];
    $org_type = $_POST['org_type']; // Added this line
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt the password

    $emailCheckSql = "SELECT * FROM recipient WHERE org_email = '$org_email'";
    $result = $conn->query($emailCheckSql);

    if ($result->num_rows > 0) {
        echo "<script>alert('Email is already registered!');window.location.replace('register.php');</script>";
    } else {
        // Insert the basic information into the users table
        $sql = "INSERT INTO recipient (org_name, org_email, owner_name, doe, address, objective, org_type, password) VALUES ('$org_name', '$org_email', '$owner_name', '$doe', '$address', '$objective', '$org_type', '$password')"; // Modified this line
        
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Registration successful!');window.location.replace('index.php');</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }

    // Close the database connection
    $conn->close();
}
?>
