<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';

    $mail = new PHPMailer(true);

    try {
        echo "<div style='display:none'>";
        $mail->SMTPDebug = 2;
        $mail->isSMTP();                                         
        $mail->Host = 'mail.iotcloud22.in';                        
        $mail->SMTPAuth = true;                                  
        $mail->Username = 'mail@iotcloud22.in';            
        $mail->Password = 'iotcloud22@123';                      
        $mail->SMTPSecure = 'tls';                               
        $mail->Port = 587;                                       

        $mail->setFrom('mail@iotcloud22.in', 'Admin');
        $mail->addAddress($email); 

        $mail->isHTML(true);
        $mail->Subject = 'Special Donation Reminder';
        $mail->Body = "Dear Donor,<br><br>Today is a special day because of the following reason: <b>$reason</b>.<br>We encourage you to make a donation to help others on this meaningful occasion.<br><br>Thank you for your generosity!";

        $mail->send();
        echo "Mail has been sent successfully!";
        echo "</div>";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
// }
?>
