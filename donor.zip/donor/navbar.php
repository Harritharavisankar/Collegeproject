<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .navbar {
    background-color: #343a40; /* Dark background color */
}

.navbar-brand {
    font-weight: bold;
}

.navbar-nav .nav-link {
    color: #f8f9fa; /* Light text color */
    transition: color 0.3s;
}

.navbar-nav .nav-link:hover {
    color: #ffc107; /* Highlight color on hover */
}

.navbar-nav .nav-link.active {
    font-weight: bold;
    border-bottom: 2px solid #ffc107; /* Underline for active link */
}

.dropdown-item:hover {
    background-color: rgba(255, 255, 255, 0.1); /* Darker hover effect for dropdown */
}

.btn-danger {
    margin-left: 15px;
    padding: 8px 16px;
}

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="">My Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="view_profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donation.php">Donations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="history.php">History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>


</body>
</html>