<?php 
session_start();
include("db.php");

if (!isset($_SESSION['uid'])) {
    header("Location: index.php");
    exit();
}

$email = $_SESSION['uid'];
$sql = "SELECT * FROM donor_user WHERE uid = '$email'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();
$userName = $user['name']; // Assuming there is a 'name' column in the user table
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        /* Navbar Styles */
        .navbar {
            background-color: #343a40; /* Dark background */
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: background-color 0.3s;
        }

        .navbar-brand {
            font-weight: 700;
            color: #ffc107; /* Amber color */
            transition: color 0.3s;
        }

        .navbar-brand:hover {
            color: #fff;
        }

        .navbar-nav .nav-link {
            color: #f8f9fa; /* Light text */
            margin-left: 15px;
            transition: color 0.3s, border-bottom 0.3s;
        }

        .navbar-nav .nav-link:hover {
            color: #ffc107; /* Highlight on hover */
            border-bottom: 2px solid #ffc107;
        }

        .navbar-nav .nav-link.active {
            color: #ffc107;
            border-bottom: 2px solid #ffc107;
        }

        .btn-danger {
            margin-left: 15px;
            padding: 8px 16px;
            transition: background-color 0.3s;
        }

        .btn-danger:hover {
            background-color: #c82333;
        }

        /* Dashboard and Card Styles */
        body {
            background: linear-gradient(to right, #f8f9fa, #e3f2fd);
            font-family: 'Poppins', sans-serif;
            color: #333;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            margin-top: 30px;
            text-align: center;
        }

        .header h1 {
            font-weight: 700;
            color: #007bff;
            margin-bottom: 10px;
            letter-spacing: 1px;
        }

        .header p {
            font-size: 18px;
            color: #666;
        }

        .card {
            background-color: #ffffff;
            border: none;
            border-radius: 20px;
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease-in-out;
            text-align: center;
            padding: 30px 20px;
            margin-bottom: 30px;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
        }

        .card-icon {
            font-size: 50px;
            color: #007bff;
            margin-bottom: 20px;
            transition: color 0.3s ease-in-out;
        }

        .card:hover .card-icon {
            color: #ff9800;
        }

        .card-title {
            font-size: 24px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
        }

        .card-text {
            font-size: 16px;
            color: #555;
        }

        .btn-primary {
            background-color: #007bff;
            border: none;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 500;
            border-radius: 30px;
            transition: background-color 0.3s ease-in-out;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        /* Logout button */
        .logout-btn {
            margin-top: 20px;
        }

        .logout-btn a {
            background-color: #dc3545;
            color: white;
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .logout-btn a:hover {
            background-color: #c82333;
        }

        @media (max-width: 768px) {
            .card {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="#">My Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view_profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="donation.php">Donations</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">History</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Dashboard -->
    <div class="container">
        <div class="header">
            <h1 class="text-capitalize">Welcome, <?php echo htmlspecialchars($userName); ?>!</h1>
            <p>Manage your donations and track your history seamlessly.</p>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <i class="fas fa-donate card-icon"></i>
                    <h5 class="card-title">Donation</h5>
                    <p class="card-text">Manage your donations and contributions.</p>
                    <a href="donation.php" class="btn btn-primary">Donate</a>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <i class="fas fa-history card-icon"></i>
                    <h5 class="card-title">History</h5>
                    <p class="card-text">View your donations history.</p>
                    <a href="history.php" class="btn btn-primary">View History</a>
                </div>
            </div>
        </div>
        
        <!-- <div class="logout-btn">
            <a href="logout.php">Logout</a>
        </div> -->
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
