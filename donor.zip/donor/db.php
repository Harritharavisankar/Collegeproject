<?php
$servername = "localhost";

$dbname = "cybernex_iotcloud22";
$username = "cybernex_pandi";
$password = "technologies123";
 

$conn=mysqli_connect($servername,$username,$password,$dbname);

 if($conn) {
//  	echo "Connnected Successfully";
 } else {
// 	echo "not Connected";
 }

