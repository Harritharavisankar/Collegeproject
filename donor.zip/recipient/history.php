<?php
session_start();
include("db.php");

if (!isset($_SESSION['rid'])) {
    header("Location: index.php");
    exit();
}

$rid = $_SESSION['rid']; 

$sql = "SELECT * FROM donations WHERE org = '$rid' order by did desc";
$result = mysqli_query($conn, $sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #f1f3f6;
            font-family: 'Poppins', sans-serif;
        }

        .container {
            margin-top: 50px;
        }

        h2 {
            text-align: center;
            font-weight: 600;
            color: #333;
            margin-bottom: 30px;
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
            background-color: #ffffff;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .table th {
            background-color: #007bff;
            color: white;
        }

        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }

        .table tr:hover {
            background-color: #f1f1f1;
        }

        .no-records {
            text-align: center;
            font-size: 20px;
            color: #888;
            margin-top: 20px;
        }

        .btn-back {
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            transition: background-color 0.3s;
        }

        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Donation History</h2>

    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>Donor Name</th>
                <th>Donation</th>
                <th>Donation Date</th>
                <th>Donation Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['donation_type']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['donation_date']) . "</td>";
                    echo "<td>₹" . htmlspecialchars($row['donation_amount']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo '<tr><td colspan="4" class="no-records">No records found</td></tr>';
            }
            ?>
        </tbody>
    </table>

    <div class="text-center">
        <a href="dashboard.php" class="btn-back">Back to Dashboard</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
